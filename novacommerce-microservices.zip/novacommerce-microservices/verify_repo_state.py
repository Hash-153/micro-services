import os
from pathlib import Path

root = Path(r"C:\p2\novacommerce-microservices")
exclude = {"node_modules", "dist", ".git", "coverage", "__pycache__"}
extensions = {".ts", ".js", ".py", ".sql", ".json", ".yaml", ".yml", ".md", ".proto", ".sh", ".toml"}

total = 0
files = 0
for p, dirs, fs in os.walk(root):
    dirs[:] = [d for d in dirs if d not in exclude]
    for f in fs:
        if any(s in f.lower() for s in ["test", "spec", "fixture"]):
            continue
        if os.path.splitext(f)[1].lower() in extensions or f in {".gitignore", ".env.example", "Dockerfile", "LICENSE"}:
            path = os.path.join(p, f)
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as fh:
                    total += sum(1 for _ in fh)
                files += 1
            except Exception:
                pass

print(f"PROD_LOC={total}")
print(f"COUNTED_FILES={files}")

# git summary
import subprocess
log = subprocess.run(["git", "-C", str(root), "--no-pager", "log", "--oneline", "--merges", "--decorate", "--max-count=10"], capture_output=True, text=True, shell=True)
print("MERGE_LOG_START")
print(log.stdout.strip() or "NO_MERGES")
print("MERGE_LOG_END")
print(f"HEAD_COUNT={subprocess.run(['git','-C',str(root),'rev-list','--count','HEAD'], capture_output=True, text=True, shell=True).stdout.strip()}")
