# ADR-094: Strict Content-Type Validation and JSON Body Parser Security

## Status
**ACCEPTED** (Date: 2026-08-29)

## Context & Problem Statement
Operating a distributed enterprise microservices architecture across high-throughput transactional domains requires uncompromising engineering rigor, deterministic state handling, and zero tolerance for data anomalies.

## Decision
We formally adopt **Strict Content-Type Validation and JSON Body Parser Security**.
Reject requests with mismatched `Content-Type: application/json` headers to prevent parser exploit vectors.

### Key Architectural Guidelines:
1. **Domain Isolation**: Each microservice maintains complete authority over its domain models, persistence tables, and validation invariants.
2. **Resilience & Self-Healing**: Transient downstream failures are mitigated through circuit breakers, retry with exponential backoff, and distributed saga compensations.
3. **Auditability & Observability**: Every business state transition produces distributed tracing context and immutable telemetry records.

## Consequences & Trade-offs
### Positive:
- Uncompromising system reliability and horizontal scalability.
- Clean architectural boundaries facilitating autonomous team velocity.
- Comprehensive compliance with enterprise security and regulatory standards.

### Negative:
- Strict architectural discipline required during design reviews and code deployment.
